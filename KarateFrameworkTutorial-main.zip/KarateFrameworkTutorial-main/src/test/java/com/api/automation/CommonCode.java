package com.api.automation;

public class CommonCode {

}
