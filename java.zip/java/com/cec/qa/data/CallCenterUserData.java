package com.cec.qa.data;


public class CallCenterUserData {

	
		public static String CEC_BaseURL = "https://test-rvcc.chuckecheese.com";
		public static String CEC_User1 = "uname";
		
		public static String CEC_Password = "April@123";
		//public static String CEC_Password = "A.abc4567";
		
		public static String AddNewPartyTypeCategory_Name = "Name";
		public static String AddNewPartyTypeCategory_DisplayTitle = "DisplayTitle";
		public static String AddNewPartyTypeCategory_Description = "Description";
		
		public static String UpdatePartyTypeCategory_Description = "testing";
		
		public static String storenumber = "0033";
		public static String storenumberChange = "0081";
		public static String children = "15";
		public static String adults = "2";
		
		public static String OrgName = "OrganizationNames";
		public static String OrgPhone = "9867402345";
		public static String CustomerName = "CustomerNames";
		public static String contactphone = "1234567789";
		public static String Address = "MyAddress";
		public static String City = "MyCity";
		public static String State = "NY";
		public static String zip = "100098";
		public static String CustomerComments = "Customer comments";
		public static String AgentComments = "Agent Comments";
		
		
		public static String guestName = "GuestNamess";
		public static String age = "24";
		public static String contactInfoName = "contactInfoName";
		public static String contactPhone = "9830127743";
		public static String Email = "email@mail.com";
		public static String extention = "2348";
		public static String contactName = "contactName";
		
		public static String organizationName = "organizationName";
		public static String PrincipalName = "PrincipalName";
		public static String NumberOfStudents = "109";
		public static String Ext1 = "5682";
		public static String txtPhone2 = "9743410074";
		
		public static String orgext = "0123";
		public static String orgEmail = "orgEmail@mail.com";
		public static String Contactphone = "9743410074";
		public static String reservationExt1 = "34100";
		public static String reservationPhone2 = "0962628920";
		public static String reservationExt2 = "5321";
		public static String ReservationCity = "NY";
		public static String ReservationState = "US";
		public static String ReservationZipCode = "100981";
		
		public static String StartTime_Monday = "2:00 PM";
		public static String EndTime_Monday = "4:00 PM";
		public static String MinChild_Monday = "25";
		public static String MinChild_children = "15";
		
		public static String StoreNumber = "0012";
		public static String StoreName = "testingstore";
		public static String RestaurantCity = "Wadiatest";
		public static String RestaurantState = "TX";
		public static String RestaurantZipCode = "112133";
		public static String RestaurantAddress = "test 111 streetaddress";
		public static String RestaurantManagerName = "testwadia";
		public static String RestaurantPublisherNumber = "4406";
		public static String RestaurantIVRNumber = "14400";
		public static String RestaurantPhoneNumber = "1234558691";
		
		public static String DisplayName = "TestingDisplayTitle";
		public static String Description = "TestingDescription";
		public static String Name = "TestingName1";
		
		
		
		public static String partytitle = "partytitle";
		public static String partyPrice = "12";
		
		
		
		
		
		
		
		
	}
	

