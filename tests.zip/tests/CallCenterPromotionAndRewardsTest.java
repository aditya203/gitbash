package com.cec.qa.tests;
import java.awt.AWTException;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.cec.qa.base.BaseTest;
import com.cec.qa.pages.CallCenterBookAndReviewPage;
import com.cec.qa.pages.CallCenterPromotionAndRewardsPage;
import com.cec.qa.util.TestUtil;



public class CallCenterPromotionAndRewardsTest extends BaseTest{
	CallCenterPromotionAndRewardsPage callCenterPromotionAndRewardsPage;
	CallCenterBookAndReviewPage callCenterBookAndReviewPage;


	//************************************************************************************************
	//*********************Constructor - Initialization***********************************************
	//************************************************************************************************
	public CallCenterPromotionAndRewardsTest() {
		super();
	}

	//************************************************************************************************
	//*********************@BeforeMethod**************************************************************
	//************************************************************************************************
	@BeforeMethod
	public void setUp() throws Exception {
		initialization("IE",propv.getProperty("CCR"));

		callCenterPromotionAndRewardsPage = new CallCenterPromotionAndRewardsPage();
		callCenterBookAndReviewPage = new CallCenterBookAndReviewPage();
	}

	//************************************************************************************************
	//*********************TestUtil - DATE Initialization*********************************************
	//************************************************************************************************

	String storeNumber = TestUtil.tuOldBookingStoreNumber; //StoreNumber assignment from TestUtil
	String bookingDate = Integer.toString(TestUtil.tuOldBookingWeekDayDate); //Booking Date getting from Util after checking Weekday checks.
	public int eventDate = TestUtil.tuOldBookingWeekDayDate;
	//************************************************************************************************
	//********************* TEST CASES ***************************************************************
	//************************************************************************************************


	//*******************************************************************************************************************************************
	//Test case:425:Call center : Verify Promotion (Add) configured for Group Level and Interceptor Category- Optional Party Item. 
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test(enabled=true)
	public void verifyAddPromotionForGroupLevel_TCID_425() throws InterruptedException, AWTException, IOException {
		System.out.println("----> 425:Call center : Verify Promotion (Add) configured for Group Level and Interceptor Category- Optional Party Item. ");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		String PromotionName=callCenterPromotionAndRewardsPage.validateNewPromotion("21",getFutureDateInMMDDYYYY(-30), getFutureDateInMMDDYYYY(0));
		Assert.assertTrue(PromotionName.contains("Promo"), "Promotion not displayed");
		callCenterPromotionAndRewardsPage.validateDeletePromotion(PromotionName);
	}

	//*******************************************************************************************************************************************
	//Test case:2027:	Call Center: Verify Call Center Manager successfully configure a new Discretionary Reward
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test(enabled=true)
	public void verifyCreateDiscReward_TCID_2027() throws InterruptedException, AWTException, IOException {
		System.out.println("----> 2027:	Call Center: Verify Call Center Manager successfully configure a new Discretionary Reward ");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		String RewardName=callCenterPromotionAndRewardsPage.validateNewReward(2,1,1); //Discretionary,Birthday,Call center
		//1-rewardType: 0-Automatic,1-Activity,2-Discretionary;//2-Reservation type: 0-Both,1-Birthday,2-Organization;//3-Client app:0-Both,1-Call center,2-Booksite
		Assert.assertTrue(RewardName.contains("Reward"), "Reward not displayed");
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		callCenterPromotionAndRewardsPage.validateDeleteReward(RewardName);
	}

	//*******************************************************************************************************************************************
	//Test case:276	Call Center: Rewards: Verify user is able to create a new Reward and save it using Save button
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test(enabled=true)
	public void verifyCreateAutomaticReward_TCID_276() throws InterruptedException, AWTException, IOException {
		System.out.println("----> 276	Call Center: Rewards: Verify user is able to create a new Reward and save it using Save button ");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		String RewardName=callCenterPromotionAndRewardsPage.validateNewReward(0,0,1); //Automatic,Both,Call center
		//1-rewardType: 0-Automatic,1-Activity,2-Discretionary;//2-Reservation type: 0-Both,1-Birthday,2-Organization;//3-Client app:0-Both,1-Call center,2-Booksite
		Assert.assertTrue(RewardName.contains("Reward"), "Reward not displayed");
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		callCenterPromotionAndRewardsPage.validateDeleteReward(RewardName);
	}

	//*******************************************************************************************************************************************
	//Test case:278	Call Center: Verify Reward configured for only Organisation displays on Call Center
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test(enabled=true)
	public void verifyCreateAutomaticRewardForOrg_TCID_278() throws InterruptedException, AWTException, IOException {
		System.out.println("----> 278	Call Center: Verify Reward configured for only Organisation displays on Call Center ");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		String RewardName=callCenterPromotionAndRewardsPage.validateNewReward(0,2,1); //Automatic,Organization,Call center
		//1-rewardType: 0-Automatic,1-Activity,2-Discretionary;//2-Reservation type: 0-Both,1-Birthday,2-Organization;//3-Client app:0-Both,1-Call center,2-Booksite
		Assert.assertTrue(RewardName.contains("Reward"), "Reward not displayed");
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		callCenterPromotionAndRewardsPage.validateDeleteReward(RewardName);
	}

	//*******************************************************************************************************************************************
	//Test case:280:Call Center: Verify Reward configure for All Reservation Type displaying correctly on Birthday/Organisation on Call center and Book site.
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test(enabled=true)
	public void verifyCreateAutomaticRewardAllResvType_TCID_280() throws InterruptedException, AWTException, IOException {
		System.out.println("----> 280:Call Center: Verify Reward configure for All Reservation Type displaying correctly on Birthday/Organisation on Call center and Book site. ");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		String RewardName=callCenterPromotionAndRewardsPage.validateNewReward(0,0,0); //Automatic,Both,Both
		//1-rewardType: 0-Automatic,1-Activity,2-Discretionary;//2-Reservation type: 0-Both,1-Birthday,2-Organization;//3-Client app:0-Both,1-Call center,2-Booksite
		Assert.assertTrue(RewardName.contains("Reward"), "Reward not displayed");
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		callCenterPromotionAndRewardsPage.validateDeleteReward(RewardName);
	}


	//Test cases on Promotion code

	//*******************************************************************************************************************************************
	//Test case:10351:Call Center: Verify Promotion configure for All Reservation Type displaying correctly on Birthday/Organisation on Call center and Book site.
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test(enabled=true)
	public void verifyCreatePromotionForAllResvType_TCID_10351() throws InterruptedException, AWTException, IOException {
		System.out.println("---->10351:Call Center: Verify Promotion configure for All Reservation Type displaying correctly on Birthday/Organisation on Call center and Book site. ");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		String RewardName=callCenterPromotionAndRewardsPage.validateNewReward(3,0,0); //Promtion Code,Both,Both
		//boolean result=callCenterPromotionAndRewardsPage.validateNewReward(3,1,0); //Promtion Code,Birthday,Both
		//boolean result=callCenterPromotionAndRewardsPage.validateNewReward(3,2,0); //Promtion Code,Organization,Both
		//1-rewardType: 0-Automatic,1-Activity,2-Discretionary,3-Promtion Code;//2-Reservation type: 0-Both,1-Birthday,2-Organization;//3-Client app:0-Both,1-Call center,2-Booksite
		Assert.assertTrue(RewardName.contains("Reward"), "Reward not displayed");
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		callCenterPromotionAndRewardsPage.validateDeleteReward(RewardName);
	}

	//*******************************************************************************************************************************************
	//Test case:10799:Call center:Birthday:Verify that Call Center Manager is able to applying valid promotion and booking birthday for Eligible party date
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test
	public void verifyAddPromotion_Eligible_Birthday_TCID_10799_A() throws InterruptedException, AWTException, IOException {
		System.out.println("----> 10799:Verify that Call Center Manager is able to applying valid promotion and booking birthday for Eligible party date");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		String promotion = callCenterPromotionAndRewardsPage.validateNewPromotion(3,1,1,"Eligible"); //Promotion Code,Both(Birthday/Org),Both(Callcenter/Booksite)
		callCenterBookAndReviewPage.validateBookMenu();
		callCenterBookAndReviewPage.validateStoreNumber("0081"); 
		callCenterBookAndReviewPage.validateSelectChildAdultAndDate("Birthday",1);
		callCenterBookAndReviewPage.validatePackage("Birthday","Star");
		String promocodeConf =callCenterBookAndReviewPage.validatePromotionCode(promotion,"VALID");
		callCenterBookAndReviewPage.validateGuestInformation("Birthday");
		callCenterBookAndReviewPage.validateContactInformation("BirthdayOrOrg","FALSE");				
		callCenterBookAndReviewPage.validateGetConfirmationNumber("BirthdayOrOrg");
		Assert.assertEquals(promocodeConf, promotion+" is applied.","String Mismatch");
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		callCenterPromotionAndRewardsPage.validateDeleteReward(promotion);
	}

	//*******************************************************************************************************************************************
	//Test case:10799:Call center:Event:Verify that Call Center Manager is able to applying valid promotion and booking birthday for Eligible party date
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test
	public void verifyAddPromotion_Eligible_Event_TCID_10799_B() throws InterruptedException, AWTException, IOException {
		System.out.println("----> 10799:Verify that Call Center Manager is able to applying valid promotion and booking birthday for Eligible party date");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		String promotion = callCenterPromotionAndRewardsPage.validateNewPromotion(3,2,1,"Eligible"); //Promotion Code,Both(Birthday/Org),Both(Callcenter/Booksite)		
		callCenterBookAndReviewPage.validateBookMenu();
		callCenterBookAndReviewPage.validateStoreNumber("0081"); 
		callCenterBookAndReviewPage.validateSelectChildAdultAndDate("Organizational",3);//2 - 3rd time slot ex: 01:00 PM
		callCenterBookAndReviewPage.validatePackage("Organization","120min"); //60min/90min/120min
		String promocodeConf =callCenterBookAndReviewPage.validatePromotionCode(promotion,"VALID");
		callCenterBookAndReviewPage.validateGuestInformation("Organization");
		callCenterBookAndReviewPage.validateContactInformation("BirthdayOrOrg","FALSE");
		String confirmationNumber= callCenterBookAndReviewPage.validateGetConfirmationNumber("BirthdayOrOrg");
		callCenterBookAndReviewPage.validateSearchWithConfNumber(confirmationNumber);
		Assert.assertEquals(promocodeConf, promotion+" is applied.","String Mismatch");
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		callCenterPromotionAndRewardsPage.validateDeleteReward(promotion);
	}

	//*******************************************************************************************************************************************
	//Test case:10799_C:Call center:Birthday:Verify that Call Center Manager is able to applying valid promotion and booking birthday for Eligible party date and Review in Reservation review page
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test(enabled=false)
	public void verifyAddPromotion_Eligible_Birthday_ReviewPromoCode_TCID_10799_C() throws InterruptedException, AWTException, IOException {
		System.out.println("----> 10799_C::Call center:Birthday:Verify that Call Center Manager is able to applying valid promotion and booking birthday for Eligible party date and Review in Reservation review page");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		String promotion = callCenterPromotionAndRewardsPage.validateNewPromotion(3,1,1,"Eligible"); //Promotion Code,Both(Birthday/Org),Both(Callcenter/Booksite)
		System.out.println("Promotion : "+promotion);
		callCenterBookAndReviewPage.validateBookMenu();
		callCenterBookAndReviewPage.validateStoreNumber("0081"); 
		callCenterBookAndReviewPage.validateSelectChildAdultAndDate("Birthday",1);
		callCenterBookAndReviewPage.validatePackage("Birthday","Star");
		callCenterBookAndReviewPage.validatePromotionCode(promotion,"VALID");
		callCenterBookAndReviewPage.validateGuestInformation("Birthday");
		callCenterBookAndReviewPage.validateContactInformation("BirthdayOrOrg","FALSE");				
		String confirmationNumber=callCenterBookAndReviewPage.validateGetConfirmationNumber("BirthdayOrOrg");
		callCenterBookAndReviewPage.validateSearchWithConfNumber(confirmationNumber);
		boolean promocode= callCenterBookAndReviewPage.validatePromoCode();
		Assert.assertEquals(promocode,true,"Promotion is present in Review page");
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		callCenterPromotionAndRewardsPage.validateDeleteReward(promotion);
	}


	//*******************************************************************************************************************************************
	//Test case:10802:Call center:Verify that the error message is displayed in Contact information page for valid promo code in Non eligible party date
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test(enabled=true)
	public void verifyAddPromotion_NonEligible_TCID_10802() throws InterruptedException, AWTException, IOException {
		System.out.println("----> 10802:Call center:Verify that the error message is displayed in Contact information page for valid promo code in Non eligible party date");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		String promotion = callCenterPromotionAndRewardsPage.validateNewPromotion(3,0,0,"NonEligible"); //Promotion Code,Both(Birthday/Org),Both(Callcenter/Booksite)
		System.out.println("Promotion : "+promotion);
		callCenterBookAndReviewPage.validateBookMenu();
		callCenterBookAndReviewPage.validateStoreNumber("0081"); 
		callCenterBookAndReviewPage.validateSelectChildAdultAndDate("Birthday",1);
		callCenterBookAndReviewPage.validatePackage("Birthday","Star");
		String promocodeConf =callCenterBookAndReviewPage.validatePromotionCode(promotion,"VALID");
		callCenterBookAndReviewPage.validateGuestInformation("Birthday");
		callCenterBookAndReviewPage.validateContactInformation("BirthdayOrOrg","FALSE");				
		callCenterBookAndReviewPage.validateGetConfirmationNumber("BirthdayOrOrg");
		Assert.assertEquals(promocodeConf,promotion+ " not found.","String Mismatch");
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		callCenterPromotionAndRewardsPage.validateDeleteReward(promotion);
	}

	//*******************************************************************************************************************************************
	//Test case:10801:Call center:Verify that the error message is displayed in Contact information page for invalid promo code
	//Reviewed by: Aditya on 20-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test(enabled=true)
	public void verifyInvalidPromotion_TCID_10801() throws InterruptedException, AWTException, IOException {
		System.out.println("----> 10801:Call center:Verify that the error message is displayed in Contact information page for invalid promo code");
		callCenterPromotionAndRewardsPage.RobotLogin();
		//callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		//callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		//String promotion = callCenterPromotionAndRewardsPage.validateNewPromotion(3,0,0,"Eligible");//Promotion Code,Both(Birthday/Org),Both(Callcenter/Booksite)
		//System.out.println("Promotion : "+promotion);
		callCenterBookAndReviewPage.validateBookMenu();
		callCenterBookAndReviewPage.validateStoreNumber("0081"); 
		callCenterBookAndReviewPage.validateSelectChildAdultAndDate("Birthday",1);
		callCenterBookAndReviewPage.validatePackage("Birthday","Star");
		String promocodeConf =callCenterBookAndReviewPage.validatePromotionCode("INVALIDPROMO","INVALID");
		Assert.assertEquals(promocodeConf, "INVALIDPROMO not found.","String Mismatch");
	}

	//*******************************************************************************************************************************************
	//Test case:2021:Call Center: Verify that Call Center Manager is getting error message for applying valid promotion code for Non Eligible party date
	//Reviewed by: Aditya on 15-Nov-2019
	//Test Run: PASS
	//*******************************************************************************************************************************************
	@Test(enabled=false)
	public void verifyAddPromotion_incorrectstore_TCID_2021() throws InterruptedException, AWTException, IOException {
		System.out.println("----> Call Center:Verify that Call Center Manager is getting error message for applying valid promotion code for Non Eligible party date");
		callCenterPromotionAndRewardsPage.RobotLogin();
		callCenterPromotionAndRewardsPage.validateSelectPromotionMenu();
		callCenterPromotionAndRewardsPage.validateSelectRewardMenu();
		String promotion = callCenterPromotionAndRewardsPage.validateNewPromotion(3,0,0,"Eligible"); //Promotion Code,Both(Birthday/Org),Both(Callcenter/Booksite)
		System.out.println("Promotion : "+promotion);
		callCenterBookAndReviewPage.validateBookMenu();
		callCenterBookAndReviewPage.validateStoreNumber("0031"); 
		callCenterBookAndReviewPage.validateSelectChildAdultAndDate("Birthday",1);
		callCenterBookAndReviewPage.validatePackage("Birthday","Star");
		boolean promofield =callCenterBookAndReviewPage.validatePromotionCode();
		Assert.assertEquals(promofield, true, "Promotion fields are not displayed");
	}

	//************************************************************************************************
	//*********************@AfterMethod***************************************************************
	//************************************************************************************************		
	@AfterMethod
	public void tearDown() {
		driver.quit();
	} 

}











