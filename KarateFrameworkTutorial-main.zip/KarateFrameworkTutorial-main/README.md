# Karate Framework Tutorial

Framework for testing RESTful Services with Karate Framework 

## Course Link (Discount Coupon)

https://www.udemy.com/course/rest-api-testing-with-karate-framework/?referralCode=FA82F2FFB385574703E4

## YouTube Playlist

- **RestSharp** https://www.youtube.com/playlist?list=PLlsKgYi2Lw73ox9LF5VfYMrA1eo9e7rIq

- **Selenium Webdriver** https://www.youtube.com/playlist?list=PLlsKgYi2Lw724ozNSmdSrrtU8q6a1m3ob

- **C# HttpClient** https://www.youtube.com/playlist?list=PLlsKgYi2Lw722PMqESdivKJQgRtJAdbzn

- **Selenium Webdriver with Java** https://www.youtube.com/playlist?list=PLlsKgYi2Lw73rFQH3AMmhhRYOETL5Nq6n

- **Handling Grid using Selenium Webdriver** https://www.youtube.com/playlist?list=PLlsKgYi2Lw71nuxL-Ju_kPdFyMKLed9W6

- **Data Base Connectivity - JDBC** https://www.youtube.com/playlist?list=PLlsKgYi2Lw71ty1T7HWkU0l4Sn3l-_jJZ
